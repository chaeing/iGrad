
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="login_right.css">



<form class="form_login" method="post" action="login_connect.php" style="margin:0px;">
   
    <div class="login-wrap">
        <div class="login-html">
          <div class="login-form">
              <div class="group">
                <input id="user" type="text" class="input" name="his_id" placeholder="Hisnet ID">
              </div>

              <div class="group">
                <input id="pass" type="password" class="input" name="his_pw" data-type="password" placeholder="Password">
              </div>

              <div class="group">
                <input id="check" type="checkbox" class="check" checked>
                <label for="check"><span class="icon"></span>
                  <div id="foreiner"> 해외 학생 전형 입학</div></label>
              </div>

              <div class="group">
                <input type="submit" class="button" value="Login">
              </div>
              
          </div>
        </div>
    </div>
</form>



