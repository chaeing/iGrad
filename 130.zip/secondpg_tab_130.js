
$("#taken").on('click',function(){


        var allbar1 = document.getElementById('about_container3');
        var allbar2 = document.getElementById('about_container5');
        var allbar3 = document.getElementById('about_container4');
        var allbar4 = document.getElementById('about_container6');
        var allbar5 = document.getElementById('about_container7');
        var allbar6 = document.getElementById('about_container8');
        allbar1.style.display='none';
        allbar2.style.display='none';
        allbar3.style.display='none'; 
        allbar4.style.display='none';
        allbar5.style.display='none';
        allbar6.style.display='none';   //세부항목 숨기기


        var specific2_1 = document.getElementById('container6');
        var specific2_2 = document.getElementById('container7');
        var specific2_3 = document.getElementById('container8');
        specific2_1.style.display='none';
        specific2_2.style.display='none';
        specific2_3.style.display='none';

        var specific1_1 = document.getElementById('container3');
        var specific1_2 = document.getElementById('container4');
        var specific1_3 = document.getElementById('container5');
        specific1_1.style.display='none';
        specific1_2.style.display='none';
        specific1_3.style.display='none';


        var element0 = document.getElementById('container2');
        element0.style.opacity = "1.0";
        element0.style.filter  = 'alpha(opacity=100)'; // IE fallback

        var element1 = document.getElementById('container1');
        element1.style.opacity = "1.0";
        element1.style.filter  = 'alpha(opacity=100)'; // IE fallback




        $.ajax({
                url : "secondpg_tab_taken.php",
                dataType : "html",
                async : false,
                type : "post",  // post 또는 get
                success : function(result){

                $("#alloflist").html(result);

                } 
            });  


    });




$("#basket").on('click',function(){



        $.ajax({
                url : "secondpg_tab_according_lib_130.php",
                dataType : "html",
                async : false,
                type : "post",  // post 또는 get
                success : function(result){

                $("#alloflist").html(result);


                } 
            });  

    });




