<link rel="stylesheet" type="text/css" href="secondpg_table.css">

<section> <!--for demo wrap-->
<div  class="tbl-header">
<table cellpadding="0" cellspacing="0" border="0">
  <thead>
    <tr>
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
  </thead>
</table>
</div>

<div  class="tbl-content">
<table cellpadding="0" cellspacing="0" border="0">
  <tbody>
    <tr class="hov">
      <th class="cod">전산</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">aaa12345</th>
      <th class="cla">abcdefghijklmnopqrstuvwxyz</th>
      <th class="cre">3</th>
      <th class="eng">100</th>
      <th class="par">기독교</th>
      <th class="etc">1234567891012345</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>
    <tr class="hov">
      <th class="cod">과목코드</th>
      <th class="cla">과목</th>
      <th class="cre">학점</th>
      <th class="eng">영어</th>
      <th class="par">영역</th>
      <th class="etc">비고</th>
    </tr>

  </tbody>
</table>
</div>
</section>


<script type="text/javascript" src='secondpg_table.js'></script>