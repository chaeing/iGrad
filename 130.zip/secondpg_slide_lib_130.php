

    <meta http-ｅquiv="Content-Type" content="text/html; charset=utf-8" />

    <link rel="stylesheet" type="text/css" href="secondpg_slide_lib_130.css">
    <!-- 부트스트랩 -->
    <link href="/library/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    
 
    <?php 
        $target1=10;
        $target2=15;
        $target3=20;
        $target4=10;
        $target5=15;
        $target6=20;
        $target7=10;
        $target8=15;

        $base1=24;
        $base2=36;
        $base3=45;
        $base4=24;
        $base5=36;
        $base6=45;
        $base7=24;
        $base8=36;


    //  container3의 막대바
        $bar3_1=10;
        $bar3_2=20;
        $bar3_3=10;
        $bar3_4=20;

        $bar3_1_b=30;
        $bar3_2_b=20;
        $bar3_3_b=30;
        $bar3_4_b=20;

    //  container5의 막대바
        $bar5_1=1;
        $bar5_2=15;

        $bar5_1_b=30;
        $bar5_2_b=20;

    //  container5의 막대바
        $bar8_1=1;
        $bar8_2=15;

        $bar8_1_b=30;
        $bar8_2_b=20;

     ?>



<div class = "back" id="all">

    <input type="hidden" id="t1" value="<?=$target1?>" />
    <input type="hidden" id="t2" value="<?=$target2?>" />
    <input type="hidden" id="t3" value="<?=$target3?>" />
    <input type="hidden" id="t4" value="<?=$target4?>" />
    <input type="hidden" id="t5" value="<?=$target5?>" />
    <input type="hidden" id="t6" value="<?=$target6?>" />
    <input type="hidden" id="t7" value="<?=$target7?>" />
    <input type="hidden" id="t8" value="<?=$target8?>" />

    <input type="hidden" id="b1" value="<?=$base1?>" />
    <input type="hidden" id="b2" value="<?=$base2?>" />
    <input type="hidden" id="b3" value="<?=$base3?>" />
    <input type="hidden" id="b4" value="<?=$base4?>" />
    <input type="hidden" id="b5" value="<?=$base5?>" />
    <input type="hidden" id="b6" value="<?=$base6?>" />
    <input type="hidden" id="b7" value="<?=$base7?>" />
    <input type="hidden" id="b8" value="<?=$base8?>" />

    <input type="hidden" id="tb3_1" value="<?=$bar3_1?>" />
    <input type="hidden" id="tb3_2" value="<?=$bar3_2?>" />
    <input type="hidden" id="tb3_3" value="<?=$bar3_3?>" />
    <input type="hidden" id="tb3_4" value="<?=$bar3_4?>" />

    <input type="hidden" id="bb3_1" value="<?=$bar3_1_b?>" />
    <input type="hidden" id="bb3_2" value="<?=$bar3_2_b?>" />
    <input type="hidden" id="bb3_3" value="<?=$bar3_3_b?>" />
    <input type="hidden" id="bb3_4" value="<?=$bar3_4_b?>" />

    <input type="hidden" id="tb5_1" value="<?=$bar5_1?>" />
    <input type="hidden" id="tb5_2" value="<?=$bar5_2?>" />
    <input type="hidden" id="bb5_1" value="<?=$bar5_1_b?>" />
    <input type="hidden" id="bb5_2" value="<?=$bar5_2_b?>" />


    <input type="hidden" id="tb8_1" value="<?=$bar8_1?>" />
    <input type="hidden" id="tb8_2" value="<?=$bar8_2?>" />
    <input type="hidden" id="bb8_1" value="<?=$bar8_1_b?>" />
    <input type="hidden" id="bb8_2" value="<?=$bar8_2_b?>" />

 

        <div class="progress1" id="bigcontainer" >

            <div class="box1" id="container1">
                <div class="na" id="name1">일반기초교양</div>
                <div  id="compo1"  >  </div>
            </div>

             <div class="box1" id="container2">
                <div class="na" id="name2">글로벌융합교양</div>
                <div id="compo2">  </div>
            </div>
            

            <br/>


            <div class="box2" id="container3">
                <div class="na" id="name3">신앙 및 세계관</div>
                <div id="compo3"  >  </div>
            </div>
            
            <div class="box2" id="container4">
                <div class="na" id="name4">인성 및 리더십</div>
                <div id="compo4"  >  </div>
            </div>

            <div class="box2" id="container5">
                <div class="na" id="name5">기초학문</div>
                <div id="compo5"  >  </div>
            </div>

            <br/>

            <div id="specific_bar">
                <div id="about_container3">
                    <div class ="box3" id="bar1">
                        <div class="barname">채플</div>
                        <div id="progressbar3_1"></div>
                    </div>
                
                    <div class ="box3" id="bar2">
                        <div class="barname">공동체 리더십 훈련</div>
                        <div id="progressbar3_2"></div>
                    </div> 

                    <div class ="box3" id="bar3">
                        <div class="barname">3</div>
                        <div id="progressbar3_3"></div>
                    </div>
                
                    <div class ="box3" id="bar4">
                        <div class="barname">공4 훈련</div>
                        <div id="progressbar3_4"></div>
                    </div> 
                </div>

                <div id="about_container4">
                    <div id="ment_4">
                    blabalbalbalbla
                    </div>

                </div>


                <div  id="about_container5">
                    <div class ="box3" id="bar1">
                        <div class="barname">5555</div>
                        <div id="progressbar5_1"></div>
                    </div>
                
                    <div class ="box3" id="bar2">
                        <div class="barname">5555</div>
                        <div id="progressbar5_2"></div>
                    </div> 
                </div>
            </div>
            




             <div class="box2" id="container6">
                <div class="na" id="name3">영어</div>
                <div id="compo6"  >  </div>
            </div>
            
            <div class="box2" id="container7">
                <div class="na" id="name4">소통 및 융복합</div>
                <div id="compo7"  >  </div>
            </div>

            <div class="box2" id="container8">
                <div class="na" id="name5">ICT 융합기초</div>
                <div id="compo8"  >  </div>
            </div>

            <br/>

            <div id="specific_bar">
                <div id="about_container6">
                    <div class ="box3" id="bar1">
                        <div class="barname">66</div>
                        <div id="progressbar6_1"></div>
                    </div>
                
                    <div class ="box3" id="bar2">
                        <div class="barname">66</div>
                        <div id="progressbar6_2"></div>
                    </div> 
                </div>

                <div id="about_container7">
                    <div id="ment_4">
                    777777
                    </div>

                </div>


                <div  id="about_container8">
                    <div class ="box3" id="bar1">
                        <div class="barname">88</div>
                        <div id="progressbar8_1"></div>
                    </div>
                
                    <div class ="box3" id="bar2">
                        <div class="barname">888</div>
                        <div id="progressbar8_2"></div>
                    </div> 
                </div>
            </div>



        </div>
  </div>







    
    <script src="library/bootstrap/js/bootstrap.min.js"></script>
    <script src="http://code.jquery.com/jquery.min.js" type="text/javascript"></script>

    <script type="text/javascript" src="/library/progressbar.js-master/dist/progressbar.js">//circlebar </script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
    <script src="secondpg_slide_lib_130.js">//page transition </script> 


