<link rel="stylesheet" type="text/css" href="firstmain_switch.css">
<html>

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" type="text/css" href="switch.css">


		<div class="switch_container">
		  <div class="switch">
		    <input type="radio" class="switch-input" name="view" value="140" id="140" checked>
		    <label for="140" class="switch-label switch-label-off">140학점</label>
		    <input type="radio" class="switch-input" name="view" value="130" id="130">
		    <label for="130" class="switch-label switch-label-on">130학점</label>
		    <span class="switch-selection"></span>
		  </div>
		</div>

</html>