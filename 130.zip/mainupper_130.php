

	  	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	    <link rel="stylesheet" type="text/css" href="mainupper.css">

			<!-- 부트스트랩 -->
		<link href="/library/bootstrap/css/bootstrap.min.css" rel="stylesheet">





	    <div class="row">

	    	<div class="col-md-12" id="logobg">

		 		<div id = "main_icon"  class="col-md-2 col-md-offset-5">
				  <a href="firstmain_130.php"><img id = "main_iconimg" src ="/img/igrad.png" ></a>
				</div>

				<div class="col-md-5" id="logout">
					<div class="col-md-4 col-md-offset-8 wrapper">
		  				<h1 align="center"><a href="Logout.php" class="effect-underline">logout</a></h1>
					</div>
				</div>
			</div>

			


			
		</div>










    <!-- jQuery (부트스트랩의 자바스크립트 플러그인을 위해 필요합니다) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- 모든 컴파일된 플러그인을 포함합니다 (아래), 원하지 않는다면 필요한 각각의 파일을 포함하세요 -->
    <script src="library/bootstrap/js/bootstrap.min.js"></script>
