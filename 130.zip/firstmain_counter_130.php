
    <meta http-ｅquiv="Content-Type" content="text/html; charset=utf-8" />

    <link rel="stylesheet" type="text/css" href="firstmain_progress130.css">
    <link rel="stylesheet" href="animsition-master/dist/css/animsition.min.css">
    <link href='https://fonts.googleapis.com/css?family=Lato:100,300' rel='stylesheet' type='text/css'> 
 
    <?php 
        $total=100;
        $totalbase=140;
     ?>


<div class = "back">

    <input type="hidden" id="total" value="<?=$total?>" />
    <input type="hidden" id="totalbase" value="<?=$totalbase?>" />

    <div class="animsition" >
 
        <a href="./secondpg_130.php" >
             <div class="progress4" id="container4" >  
                <div class="b" id="example-percent-container4"  >  </div>
                <div id="container4_name">Out of 140</div>
            </div>
        </a>
         
    </div>

</div>



    <script type="text/javascript" src="/library/progressbar.js-master/dist/progressbar.js">//circlebar </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js">//jquery </script>
    <script src="firstmain_progress130.js">//page transition </script> 


